# Dadar Crowd Model — SIH Prototype

## Purpose
This package trains the crowd-prediction component used by the station navigation prototype.

IMPORTANT:
The zone-level crowd records are calibrated synthetic prototype data anchored to historical Dadar passenger-flow patterns. They are NOT live Dadar occupancy measurements.

## Files

- dadar_crowd_prototype_calibrated.csv
  Training dataset.

- dadar_historical_hourly_anchor.csv
  Historical hourly station-flow anchor used to calibrate the prototype dataset.

- train_crowd_model.py
  Trains and evaluates the Random Forest regression model and creates crowd_model.pkl.

- crowd_predictor.py
  Loads crowd_model.pkl and provides predict_crowd() and crowd_level().

- test_crowd_model.py
  Tests several Dadar scenarios.

- requirements.txt
  Python packages.

## Run

1. Put all files in one folder.

2. Install dependencies:
   python -m pip install -r requirements.txt

3. Train:
   python train_crowd_model.py

4. Test:
   python test_crowd_model.py

5. The generated file crowd_model.pkl is then used by the routing system.

## Model inputs

- hour
- day_of_week
- is_weekend
- is_festival
- mins_to_next_train
- base_capacity
- zone_id
- zone_type

## Model output

crowd_score = predicted crowd intensity from 0–100

Then:

<30   LOW
30-59 MODERATE
60-79 HIGH
>=80  VERY HIGH

## SIH explanation

"We use historical passenger-flow patterns as an anchor and calibrated synthetic zone-level samples for the prototype. The ML model predicts crowd intensity for station zones. The prediction is then consumed by the routing engine, which can prefer a slightly longer route when it substantially reduces crowd exposure."

Do not call the prototype predictions live data.
